package structure;

public class Cell {
	public boolean visited=false;
	public boolean blocked=false;
	public int h,g,f;
	public Point p;
	public Cell(int x, int y) {
		p=new Point(x,y);
	}
}
