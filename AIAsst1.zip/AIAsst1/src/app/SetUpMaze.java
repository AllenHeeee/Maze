package app;

import java.util.ArrayList;
import java.util.Stack;

import structure.Cell;
import structure.Point;

public class SetUpMaze {
	public static ArrayList<Point> getNeighbor(Point p,Cell[][] map) {
		int currentX=p.x, currentY=p.y;
		ArrayList<Point> list = new ArrayList<Point>();
		if(currentX+1<map.length&&!map[currentX+1][currentY].visited) {
			list.add(new Point(currentX+1,currentY));
		}
		if(currentX-1>=0&&!map[currentX-1][currentY].visited) {
			list.add(new Point(currentX-1,currentY));
		}
		if(currentY+1<map[0].length&&!map[currentX][currentY+1].visited) {
			list.add(new Point(currentX,currentY+1));
		}
		if(currentY-1>=0&&!map[currentX][currentY-1].visited) {
			list.add(new Point(currentX,currentY-1));
		}
		return list;
	}
	public static Point getOneFromList(ArrayList<Point> list) {
		if(list.size()==1)return list.remove(0);
		double random=Math.random();
		if(list.size()==2) {
			if(random<=0.5) {
				return list.remove(0);
			}
			return list.remove(1);
		}
		if(list.size()==3) {
			if(random<=0.33) {
				return list.remove(0);
			}
			if(random<=0.66) {
				return list.remove(1);
			}
			return list.remove(2);
		}
		if(list.size()==4) {
			if(random<=0.25) {
				return list.remove(0);
			}
			if(random<=0.5) {
				return list.remove(1);
			}
			if(random<=0.75)
			return list.remove(2);
			return list.remove(3);
		}
		return null;
	}
	public static Cell[][] setUp() {
		
		Cell[][] map = new Cell[101][101];
		for(int i=0;i<101;i++) {
			for(int j=0;j<101;j++) {
				map[i][j]=new Cell(i,j);
			}
		}
		Point randomPoint = 
		new Point( (int)(Math.random() * 100 + 1),(int)(Math.random() * 100 + 1));
		
		Stack<Point> stack = new Stack<Point>();
		stack.push(randomPoint);
		map[randomPoint.x][randomPoint.y].visited=true;
		while(!stack.isEmpty()) {
			Point currentP=stack.peek();
			ArrayList<Point> nextPoints=getNeighbor(currentP, map);
			if(!nextPoints.isEmpty()) {
				Point nextP=getOneFromList(nextPoints);
				map[nextP.x][nextP.y].visited=true;
				if(Math.random()<=0.3) {
					map[nextP.x][nextP.y].blocked=true;
				}
				stack.push(nextP);
			}else {
				stack.pop();
			}
		}
		
		// Out print the maze
		for(int i=0;i<101;i++) {
			for(int j=0;j<101;j++) {
				if(map[i][j].blocked) {
					System.out.print('X');
				}else {
					System.out.print('.');
				}
			}
			System.out.println();
		}
		System.out.println();
		System.out.println();
		return map;
	}
	public static ArrayList<Cell[][]> set50() {
		ArrayList<Cell[][]> list = new ArrayList<Cell[][]>();
		for(int i=0;i<50;i++) {
			System.out.println(i+1);
			list.add(setUp());
		}
		return list;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		set50();
	}

}
